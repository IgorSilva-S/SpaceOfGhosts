let fly = "./assets/sprites/skins/ghost/fly.gif";
let upAnim = "./assets/sprites/skins/ghost/upAnim-S.gif";
let downAnim = "./assets/sprites/skins/ghost/downAnim-S.gif";
let downAnimF = "./assets/sprites/skins/ghost/downAnim-F.gif";
let upAnimF = "./assets/sprites/skins/ghost/upAnim-F.gif";
let stopImg = "./assets/sprites/skins/ghost/stop.png"